package Views;
import DAO.UserDAO;
import Model.User;
import Service.GenerateOTP;
import Service.SendOTPService;
import Service.UserService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.Scanner;


public class Welcome {
        public void welcomeScreen() {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Welcome to the app");
            System.out.println("Enter 1 for login");
            System.out.println("Enter 2 for signIn");
            System.out.println("Enter 0 for exit");
            int choice = 0;
            try {
                String input = br.readLine().trim();
                choice = input.matches("\\d") ? Integer.parseInt(input) : -1;
            } catch (IOException e) {
                System.out.println("Error reading input.");
            }


            switch (choice) {
                case 1 -> login();
                case 2 -> signUp();
                case 0 -> System.exit(0);
                default -> System.out.println("Invalid choice, Please Try again");
            }
        }

        private static void login () {
            try (Scanner sc = new Scanner (System.in)) {
                System.out.println("Enter ur email");
                String email = sc.nextLine();
                try{
                    if(UserDAO.isExist(email)){
                        String genOTP = GenerateOTP.getOTP();
                        SendOTPService.sendOTP(email,genOTP);
                        System.out.println("Enter the OTP");
                        String otp = sc.nextLine();
                        if(otp.equals(genOTP)){
                            new UserView(email).home();
                        }
                        else{
                            System.out.println("Wrong OTP");
                        }
                    }
                    else{
                        System.out.println("User Not Exists");
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }

        }
        private static void signUp () {
            try (Scanner sc = new Scanner(System.in)) {
                System.out.println("Enter ur Name");
                String name  = sc.nextLine();
                System.out.println("Enter ur Email");
                String email = sc.nextLine();
                String genOTP = GenerateOTP.getOTP();
                SendOTPService.sendOTP(email,genOTP);
                System.out.println("Enter the otp");
                String otp = sc.nextLine();
                if(otp.equals(genOTP)){
                    User user = new User(name,email);
                    int Response = UserService.saveUser(user);
                    switch(Response){
                        case 1 -> System.out.println("User Registered");
                        case 0 -> System.out.println("User already exists");
                    }
                }
                else{
                    System.out.println("Wrong OTP");
                }
            }

        }

}



