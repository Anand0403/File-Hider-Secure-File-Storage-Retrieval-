package Views;

import DAO.DataDAO;
import Model.Data;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class UserView {
    private String email;
    private static final Scanner sc = new Scanner(System.in); // Keep Scanner open globally

    public UserView(String email) {
        this.email = email;
    }

    public void home() {
        do {
            System.out.println("Welcome " + this.email);
            System.out.println("Press 1 to show Already Hidden files");
            System.out.println("Press 2 to hide a new file");
            System.out.println("Press 3 to Unhide the File");
            System.out.println("Press 0 to exit");

            try {
                int ch = Integer.parseInt(sc.nextLine().trim()); // Read input safely

                switch (ch) {
                    case 1 -> {
                        try {
                            List<Data> files = DataDAO.getAllFies(this.email);
                            System.out.println("ID  -  File Name");
                            for (Data file : files) {
                                System.out.println(file.getID() + " - " + file.getFileName());
                            }
                        } catch (SQLException e) {
                            System.out.println("Error retrieving files.");
                            e.printStackTrace();
                        }
                    }
                    case 2 -> {
                        System.out.println("Enter the file path:");
                        String path = sc.nextLine().trim();
                        File f = new File(path);
                        if (!f.exists()) {
                            System.out.println("Error: File does not exist!");
                            continue;
                        }

                        Data file = new Data(0, f.getName(), path, email);
                        try {
                            DataDAO.hideFiles(file);
                        } catch (SQLException | IOException e) {
                            System.out.println("Error hiding file.");
                            e.printStackTrace();
                        }
                    }
                    case 3 -> {
                        try {
                            List<Data> files = DataDAO.getAllFies(this.email);

                            System.out.println("ID - File Name");
                            for (Data file : files) {
                                System.out.println(file.getID() + " - " + file.getFileName());
                            }

                            System.out.println("Enter the ID of the file to unhide:");
                            int id = Integer.parseInt(sc.nextLine().trim());

                            boolean isValidID = false;
                            for (Data file : files) {
                                if (file.getID() == id) {
                                    isValidID = true;
                                    break;
                                }
                            }

                            if (isValidID) {
                                DataDAO.unhide(id);
                            } else {
                                System.out.println("Wrong ID, please try again.");
                            }
                        } catch (SQLException | IOException e) {
                            System.out.println("Error unhiding file.");
                            e.printStackTrace();
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input! Please enter a valid number.");
                        }
                    }
                    case 0 -> {
                        System.out.println("Exiting...");
                        sc.close(); // Close Scanner before exiting
                        System.exit(0);
                    }
                    default -> System.out.println("Invalid choice, Please Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a valid number.");
            }
        } while (true);
    }
}
