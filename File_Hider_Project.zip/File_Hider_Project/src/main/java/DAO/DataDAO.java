package DAO;

import Model.Data;
import dB.MyConnection;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataDAO { // show file,hide file,unhide file

    public static List<Data> getAllFies(String email) throws SQLException {
        Connection connection  = MyConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement("select * from data where email = ?");
        ps.setString(1,email);
        ResultSet rs = ps.executeQuery();

        List<Data> files = new ArrayList<>();
        while(rs.next()){
            int ID = rs.getInt(1);
            String fileName = rs.getString(2);
            String path = rs.getString(3);
            files.add(new Data(ID,fileName,path));
        }
        return files;
    }
    public static void hideFiles(Data file) throws SQLException, IOException {
        File f = new File(file.getPath());

        System.out.println("Checking file: " + file.getPath());
        System.out.println("File exists: " + f.exists());
        System.out.println("File readable: " + f.canRead());
        System.out.println("File absolute path: " + f.getAbsolutePath());

        if (!f.exists()) {
            throw new FileNotFoundException("File " + file.getPath() + " does not exist.");
        }

        String query = "INSERT INTO data(filename, path, email, bin_data) VALUES (?, ?, ?, ?)";

        try (Connection connection = MyConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             FileInputStream fis = new FileInputStream(f)) { // ✅ Use FileInputStream instead of FileReader

            ps.setString(1, file.getFileName());
            ps.setString(2, file.getPath());
            ps.setString(3, file.getEmail());
            ps.setBinaryStream(4, fis, f.length()); // ✅ Store file as binary data

            int ans = ps.executeUpdate();
            System.out.println("File successfully hidden in DB!");

            if (ans > 0) {
                fis.close(); // ✅ Close file stream before deleting
                Thread.sleep(500); // ✅ Short delay to release file lock

                if (f.delete()) {
                    System.out.println("File deleted from system: " + file.getPath());
                } else {
                    System.out.println("Warning: Failed to delete file from system. File may be in use.");
                    f.deleteOnExit(); // ✅ Ensures deletion on JVM exit
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }



    public static void unhide(int ID) throws SQLException, IOException {
        Connection connection = MyConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement("SELECT path, bin_data FROM data WHERE ID = ?");
        ps.setInt(1, ID);
        ResultSet rs = ps.executeQuery();

        // ✅ Ensure the result set has data before accessing it
        if (!rs.next()) {
            System.out.println("Error: No file found with the given ID.");
            return;
        }

        String path = rs.getString("path");
        Blob blob = rs.getBlob("bin_data"); // ✅ Use Blob for binary data

        try (InputStream is = blob.getBinaryStream();
             FileOutputStream fos = new FileOutputStream(path)) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
        }

        // ✅ Delete file entry from database after restoring
        try (PreparedStatement deletePs = connection.prepareStatement("DELETE FROM data WHERE ID = ?")) {
            deletePs.setInt(1, ID);
            deletePs.executeUpdate();
        }

        System.out.println("Successfully Unhidden the File: " + path);
    }

}
