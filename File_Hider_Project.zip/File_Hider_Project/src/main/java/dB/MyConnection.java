package dB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
    public static Connection connection; //As it was declared in the class level so it is always the null
    public static Connection getConnection(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); //Load the Driver
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/file_hider_project?useSSL=false", "root", "Anand@123");//Establish the Connection
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        System.out.println("Successfully Completed the Connection");
        return connection;
    }

    public static void CloseConnection(){
        if(connection != null){
            try{
                connection.close();
            }
            catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

}


