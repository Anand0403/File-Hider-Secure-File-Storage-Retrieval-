package Model;

public class Data {
    private  int ID;
    private String fileName;
    private String path;
    private String email;


    public Data(int ID,String fileName,String path,String email){
        this.ID = ID;
        this.fileName = fileName;
        this.path = path;
        this.email = email;
    }

    public Data(int ID,String filename,String path){
        this.ID = ID;
        this.fileName  = filename;
        this.path = path;
    }
    public int getID(){
        return ID;
    }
    public void setID(int ID){
        this.ID = ID;
    }

    public String getFileName(){
        return fileName;
    }
    public void setFileName(String fileName){
        this.fileName = fileName;
    }

    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }

    public String getPath(){
        return path;
    }
    public void setPath(String path){
        this.path = path;
    }
}
